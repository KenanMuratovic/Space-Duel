import pygame
import os
import SpaceDuel
import random

pygame.display.set_caption("Space Duel")

pygame.mixer.init()
BULLET_HIT_SOUND = pygame.mixer.Sound(os.path.join(('Assets'), 'Grenade.wav'))
BULLET_FIRE_SOUND = pygame.mixer.Sound(os.path.join(('Assets'), 'Gun.wav'))

FPS = 60
MAX_BULLETS = 4
HEIGHT = SpaceDuel.HEIGHT
WIDTH = SpaceDuel.WIDTH


def main():
    red = pygame.Rect(750, 500, SpaceDuel.SPACESHIP_WIDTH, SpaceDuel.SPACESHIP_HEIGHT)
    yellow = pygame.Rect(100, 300, SpaceDuel.SPACESHIP_WIDTH, SpaceDuel.SPACESHIP_HEIGHT)

    red_bullets = []
    yellow_bullets = []

    red_health = 5
    yellow_health = 5

    direction = 0

    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and len(yellow_bullets) < MAX_BULLETS:
                    bullet = pygame.Rect(yellow.x + yellow.width, yellow.y + yellow.height//2 - 2, 10, 5)
                    yellow_bullets.append(bullet)
                    BULLET_FIRE_SOUND.play()

            if abs(red.y - yellow.y) < 200 and len(red_bullets) < MAX_BULLETS:
                bullet = pygame.Rect(red.x, red.y + red.height//2 - 2, 10, 5)
                red_bullets.append(bullet)
                BULLET_FIRE_SOUND.play()

            if event.type == SpaceDuel.RED_HIT:
                red_health -= 1
                BULLET_HIT_SOUND.play()

            if event.type == SpaceDuel.YELLOW_HIT:
                yellow_health -= 1
                BULLET_HIT_SOUND.play()

        winner_text = ""
        if red_health <= 0:
            winner_text = "Pobijedio si!"
        if yellow_health <= 0:
            winner_text = "Izgubio si! Nauci da igras!!!"
        if winner_text != "":
            SpaceDuel.draw_winner(winner_text)
            break
        keys_pressed = pygame.key.get_pressed()
        SpaceDuel.yellow_handle_movement(keys_pressed, yellow)

        # AI pomjeranje
        if red.x < WIDTH//2:
            direction = random.choice([1, 2])
        elif red.x > WIDTH - SpaceDuel.SPACESHIP_WIDTH:
            direction = random.choice([0, 3])
        elif red.y < 0:
            direction = random.choice([2, 3])
        elif red.y > HEIGHT - SpaceDuel.SPACESHIP_HEIGHT - 15:
            direction = random.choice([0, 1])

        SpaceDuel.red_ai_handle_movement(yellow_bullets, red, direction)
        SpaceDuel.handle_bullets(yellow_bullets, red_bullets, yellow, red)
        SpaceDuel.draw_window(red, yellow, red_bullets, yellow_bullets, red_health, yellow_health)

    main()


if __name__ == "__main__":
    main()
